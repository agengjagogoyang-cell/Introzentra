# ZentraIntro 2.0.1

Intro sinematik untuk **ZentraSMP**: begitu pemain join dan loading selesai, pemain langsung
dipindah ke lobby (`/spawn`), kamera terbang mengelilingi lobby dengan judul, bossbar loading,
timelapse malam ke siang, partikel sihir dan kembang api. Di akhir layar **menggelap perlahan**,
lalu **terang perlahan** dan pemain bisa bermain.

- Server: **Purpur / Paper 1.21+** (kode tidak memakai NMS atau versi tertentu, `api-version: 1.21`)
- Bedrock: **Geyser + Floodgate** didukung (otomatis terdeteksi)
- Tanpa resource pack, tanpa dependency wajib

## Cara membuat file .jar lewat GitHub Actions

1. Upload seluruh isi arsip ini ke **root** repository GitHub kamu (pastikan `pom.xml`, `src/`, dan `.github/workflows/build.yml` ada di folder utama repo, bukan di dalam sub-folder).
2. Buka tab **Actions** -> **Build ZentraIntro** -> **Run workflow** (atau otomatis jalan saat push ke `main`).
3. Setelah selesai (centang hijau), buka bagian **Artifacts** di bawah ringkasan run dan unduh **`ZentraIntro-jar`** (berisi `ZentraIntro.jar`).

## Instalasi di Server

1. Taruh `ZentraIntro.jar` di folder `plugins/`.
2. Pastikan ada plugin `/spawn` (EssentialsX + EssentialsSpawn) dan lobby sudah di-`/setspawn`.
   Kalau tidak ada atau tidak memindahkan pemain, plugin otomatis melakukan fallback ke spawn world (`spawn.fallback-to-world-spawn`).
3. Restart server. Edit `plugins/ZentraIntro/config.yml` lalu `/zentraintro reload`.

## Perintah dan Permission

| Perintah | Fungsi |
|---|---|
| `/zentraintro play [pemain]` | Jalankan intro (untuk tes tanpa relog) |
| `/zentraintro stop [pemain]` | Hentikan intro dan kembalikan pemain |
| `/zentraintro reload` | Muat ulang config |

- `zentraintro.admin` (default op): memakai perintah di atas.
- `zentraintro.bypass`: melewati intro saat join. Staff yang punya permission `*` juga ikut melewati.
